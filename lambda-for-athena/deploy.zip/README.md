# Athena Query

Restful API로 Athena를 query하도록 만들 예정 : 현재 오류 잡는중

## Reference 

[JavaScript (SDK V2) Code Examples for Amazon Athena](https://docs.aws.amazon.com/code-samples/latest/catalog/code-catalog-javascript-example_code-athena.html)
