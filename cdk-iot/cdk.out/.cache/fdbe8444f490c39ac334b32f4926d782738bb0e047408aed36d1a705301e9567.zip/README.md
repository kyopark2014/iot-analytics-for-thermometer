
## Reference

[Visualization - Google Charts](https://developers.google.com/chart/interactive/docs/gallery/areachart) 

