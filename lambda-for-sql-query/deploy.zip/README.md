# Athena Query

## Reference 

[JavaScript (SDK V2) Code Examples for Amazon Athena](https://docs.aws.amazon.com/code-samples/latest/catalog/code-catalog-javascript-example_code-athena.html)
